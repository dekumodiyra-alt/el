export default {
  love: "❤️",
  fire: "🔥",
  music: "🎵",
  dance: "💃",
  heart: "💓",
  smile: "😊",
  sad: "😢",
  cool: "😎",
  happy: "😁",
  star: "⭐",
  moon: "🌙",
  sun: "☀️",
};